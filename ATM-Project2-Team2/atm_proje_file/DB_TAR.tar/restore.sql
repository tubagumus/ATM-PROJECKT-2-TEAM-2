--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7
-- Dumped by pg_dump version 14.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accountList; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."accountList" (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    surname character varying(15) NOT NULL,
    balance integer NOT NULL,
    "e-mail" character varying(25) NOT NULL,
    "tax-number" integer NOT NULL,
    password character varying NOT NULL
);


ALTER TABLE public."accountList" OWNER TO postgres;

--
-- Name: againtablecreate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.againtablecreate (
    id integer NOT NULL,
    ad character varying(20) NOT NULL,
    marka character varying(20),
    stok integer,
    katagori character varying(20)
);


ALTER TABLE public.againtablecreate OWNER TO postgres;

--
-- Name: againtablecreate2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.againtablecreate2 (
    id integer NOT NULL,
    ad character varying(20) NOT NULL,
    marka character varying(20),
    stok integer,
    katagori character varying(20)
);


ALTER TABLE public.againtablecreate2 OWNER TO postgres;

--
-- Name: csv.csv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."csv.csv" (
    name character varying[],
    vise integer[],
    final integer[]
);


ALTER TABLE public."csv.csv" OWNER TO postgres;

--
-- Name: csvfor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.csvfor (
    name character varying(50)[] NOT NULL,
    vise integer[],
    final integer[]
);


ALTER TABLE public.csvfor OWNER TO postgres;

--
-- Name: forimportcsv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.forimportcsv (
    name character varying NOT NULL,
    "3" character varying,
    "5" character varying,
    "6" character varying,
    "7" character varying,
    "2" character varying,
    "4" character varying
);


ALTER TABLE public.forimportcsv OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    payment_id integer NOT NULL,
    customer_id integer NOT NULL,
    "stuff id" integer NOT NULL,
    rental_id integer NOT NULL,
    amount integer NOT NULL,
    payment_date integer NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: tryTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."tryTable" (
    "1" character varying NOT NULL,
    "22" character varying,
    "3" character varying,
    "4" character varying,
    "5" character varying,
    "6" character varying,
    "7" character varying
);


ALTER TABLE public."tryTable" OWNER TO postgres;

--
-- Name: urunn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urunn (
    id integer NOT NULL,
    ad character varying(20) NOT NULL,
    marka character varying(20),
    stok integer,
    katagori character varying(20)
);


ALTER TABLE public.urunn OWNER TO postgres;

--
-- Data for Name: accountList; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."accountList" (id, name, surname, balance, "e-mail", "tax-number", password) FROM stdin;
\.
COPY public."accountList" (id, name, surname, balance, "e-mail", "tax-number", password) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: againtablecreate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.againtablecreate (id, ad, marka, stok, katagori) FROM stdin;
\.
COPY public.againtablecreate (id, ad, marka, stok, katagori) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: againtablecreate2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.againtablecreate2 (id, ad, marka, stok, katagori) FROM stdin;
\.
COPY public.againtablecreate2 (id, ad, marka, stok, katagori) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: csv.csv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."csv.csv" (name, vise, final) FROM stdin;
\.
COPY public."csv.csv" (name, vise, final) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: csvfor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.csvfor (name, vise, final) FROM stdin;
\.
COPY public.csvfor (name, vise, final) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: forimportcsv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.forimportcsv (name, "3", "5", "6", "7", "2", "4") FROM stdin;
\.
COPY public.forimportcsv (name, "3", "5", "6", "7", "2", "4") FROM '$$PATH$$/3354.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (payment_id, customer_id, "stuff id", rental_id, amount, payment_date) FROM stdin;
\.
COPY public.payment (payment_id, customer_id, "stuff id", rental_id, amount, payment_date) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: tryTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."tryTable" ("1", "22", "3", "4", "5", "6", "7") FROM stdin;
\.
COPY public."tryTable" ("1", "22", "3", "4", "5", "6", "7") FROM '$$PATH$$/3359.dat';

--
-- Data for Name: urunn; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.urunn (id, ad, marka, stok, katagori) FROM stdin;
\.
COPY public.urunn (id, ad, marka, stok, katagori) FROM '$$PATH$$/3355.dat';

--
-- Name: accountList accountList_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."accountList"
    ADD CONSTRAINT "accountList_pkey" PRIMARY KEY (id);


--
-- Name: againtablecreate2 againtablecreate2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.againtablecreate2
    ADD CONSTRAINT againtablecreate2_pkey PRIMARY KEY (id);


--
-- Name: againtablecreate againtablecreate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.againtablecreate
    ADD CONSTRAINT againtablecreate_pkey PRIMARY KEY (id);


--
-- Name: csvfor csvfor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.csvfor
    ADD CONSTRAINT csvfor_pkey PRIMARY KEY (name);


--
-- Name: forimportcsv forimportcsv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.forimportcsv
    ADD CONSTRAINT forimportcsv_pkey PRIMARY KEY (name);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);


--
-- Name: tryTable tryTable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."tryTable"
    ADD CONSTRAINT "tryTable_pkey" PRIMARY KEY ("1");


--
-- Name: urunn urunn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunn
    ADD CONSTRAINT urunn_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

